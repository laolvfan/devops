FROM python:3.13-slim@sha256:70729b46c69b4f1e97c4822c1af3df53a1476cf5ddc6c087c0c10bc3a5678c2f
RUN sed -i \
    -e s@http://deb.debian.org/debian-security@https://mirrors.aliyun.com/debian-security@g \
    -e s@http://deb.debian.org/debian@https://mirrors.aliyun.com/debian@g \
    /etc/apt/sources.list.d/debian.sources \
    && apt-get -o Acquire::Retries=1 -o Acquire::https::Timeout=30 update \
    && apt-get install -y --no-install-recommends gcc make libc6-dev \
    && rm -rf /var/lib/apt/lists/*
WORKDIR /work
COPY main.c Makefile ./
RUN exit 23
RUN make
CMD ["./hello"]
